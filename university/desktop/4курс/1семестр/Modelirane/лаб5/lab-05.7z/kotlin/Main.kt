object Main {

    @JvmStatic
    fun main(args: Array<String>) {
        val model = hardcodedInput()
        printResults(model)
    }

    fun hardcodedInput(): Model {
        val clientM: Double = 10.0
        val clientD: Double = 2.0
        val op0M: Double = 20.0
        val op0D: Double = 5.0
        val op1M: Double = 40.0
        val op1D: Double = 10.0
        val op2M: Double = 40.0
        val op2D: Double = 20.0
        val comp0M: Double = 15.0
        val comp1M: Double = 30.0
        val cCount: Int = 300

        println("Клиенты:")
        println("Интервал = $clientM +- $clientD")
        println("К=во заявок = $cCount")

        println("Операторы:")
        println("#1 Интервал = $op0M +- $op0D")
        println("#2 Интервал = $op1M +- $op1D")
        println("#3 Интервал = $op2M +- $op2D")

        println("Компьютеры:")
        println("#1 Интервал = $comp0M")
        println("#2 Интервал = $comp1M")

        return Model(
            clientM = clientM, clientD = clientD,
            op0M = op0M, op0D = op0D,
            op1M = op1M, op1D = op1D,
            op2M = op2M, op2D = op2D,
            comp0M = comp0M,
            comp1M = comp1M,
            cCount = cCount
        )

    }

    fun printResults(model: Model) {
        val (denialP, missedCount) = model.eventBasedModelling()
        println(" -------- Результаты моделирования --------------------")
        println("Вероятность отказа:    $denialP")
        println("Необработанные заявки: $missedCount")

    }
}
