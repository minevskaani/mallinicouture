package generator

class ConstGenerator(private val m: Double): IGenerator {
    override fun next() = m
}