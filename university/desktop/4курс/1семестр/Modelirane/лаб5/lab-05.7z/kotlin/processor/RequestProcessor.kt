package processor

import generator.IGenerator
import generator.RequestGenerator

class RequestProcessor(generator: IGenerator, val maxQueueSize: Int = 0): RequestGenerator(generator) {
    var queuedRequests: Int = 0
        private set
    var queueSize: Int = maxQueueSize
    var processedRequests: Int = 0
        private set

    fun process(): Boolean {
        if (queuedRequests > 0) {
            processedRequests++
            queuedRequests--
            return emitRequest() != null
        }

        return false
    }

    fun receiveRequest(): Boolean {
        if (maxQueueSize == 0) {
            if (queuedRequests >= queueSize) {
                queueSize++
            }
            queuedRequests++
            return true
        } else if (queuedRequests < queueSize) {
            queuedRequests++
            return true
        }

        return false
    }
}