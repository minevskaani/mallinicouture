package generator

import processor.RequestProcessor

open class RequestGenerator(var generator: IGenerator) {
    private val receivers: ArrayList<RequestProcessor> = arrayListOf()
    var generatedRequests: Int = 0
        private set
    var nextEventTime: Double = 0.0

    fun addReceiver(receiver: RequestProcessor) {
        if (receiver !in receivers){
            receivers.add(receiver)
        }
    }

    fun removeReceiver(receiver: RequestProcessor) = receivers.remove(receiver)

    fun generateTime() = generator.next()

    fun emitRequest(): RequestProcessor? {
        generatedRequests++
        receivers.forEach { if (it.receiveRequest()) return it }

        return null
    }
}