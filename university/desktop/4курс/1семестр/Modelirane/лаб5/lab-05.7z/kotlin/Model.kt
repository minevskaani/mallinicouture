import generator.ConstGenerator
import generator.RequestGenerator
import generator.UniformGenerator
import processor.RequestProcessor
import java.util.*

class Model(
    val clientGen: RequestGenerator,
    val op0: RequestProcessor,
    val op1: RequestProcessor,
    val op2: RequestProcessor,
    val comp0: RequestProcessor,
    val comp1: RequestProcessor,
    val cCount: Int
) {
    val devices: ArrayList<RequestGenerator> = arrayListOf()
    init {
        clientGen.addReceiver(op0)
        clientGen.addReceiver(op1)
        clientGen.addReceiver(op2)
        op0.addReceiver(comp0)
        op0.addReceiver(comp0)
        op0.addReceiver(comp1)

        devices.addAll(listOf(clientGen, op0, op1, op2, comp0, comp1))
    }

    constructor(
        clientM: Double, clientD: Double,
        op0M: Double, op0D: Double,
        op1M: Double, op1D: Double,
        op2M: Double, op2D: Double,
        comp0M: Double,
        comp1M: Double,
        cCount: Int
    ) : this(
        clientGen = RequestGenerator(UniformGenerator(clientM, clientD)),
        op0 = RequestProcessor(UniformGenerator(op0M, op0D), maxQueueSize = 1),
        op1 = RequestProcessor(UniformGenerator(op1M, op1D), maxQueueSize = 1),
        op2 = RequestProcessor(UniformGenerator(op2M, op2D), maxQueueSize = 1),
        comp0 = RequestProcessor(ConstGenerator(comp0M)),
        comp1 = RequestProcessor(ConstGenerator(comp1M)),
        cCount = cCount
    )

    fun eventBasedModelling(): Pair<Double, Int> {
        // Init time
        devices.forEach { it.nextEventTime = 0.0 }

        var droppedRequests: Int = 0
        clientGen.nextEventTime = clientGen.generateTime()
        while (clientGen.generatedRequests < cCount) {
            var currentTime = clientGen.nextEventTime

            // Sync time
            devices.forEach { if (0 < it.nextEventTime && it.nextEventTime < currentTime) currentTime = it.nextEventTime }

            for (device in devices) {
                if (currentTime == device.nextEventTime) {
                    when (device) {
                        is RequestProcessor -> {
                            device.process()
                            if (device.queuedRequests == 0) {
                                device.nextEventTime = 0.0
                            } else {
                                device.nextEventTime = currentTime + device.generateTime()
                            }
                        }
                        else -> {
                            val assignedProcessor = clientGen.emitRequest()
                            if (assignedProcessor != null) {
                                assignedProcessor.nextEventTime = currentTime + assignedProcessor.generateTime()
                            } else {
                                droppedRequests++
                            }

                            clientGen.nextEventTime = currentTime + clientGen.generateTime()
                        }
                    }
                }
            }
        }

        return Pair(droppedRequests.toDouble() / cCount, droppedRequests)
    }
}