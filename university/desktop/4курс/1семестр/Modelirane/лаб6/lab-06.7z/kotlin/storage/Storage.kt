package storage

class Storage(val maxSize: Int) {

    var currSize: Int = 0
        private set
    private val isUnlimited = maxSize == 0

    fun isFull() = !isUnlimited && currSize == maxSize
    fun isEmpty() = currSize == 0

    fun offer(): Boolean {
        if (!isFull()) {
            currSize++
            return true
        }

        return false
    }

    fun pull(): Boolean {
        if (!isEmpty()){
            currSize--
            return true
        }

        return false
    }

    override fun toString(): String {
        return "Storage(elements=$currSize, size=$maxSize)"
    }


}