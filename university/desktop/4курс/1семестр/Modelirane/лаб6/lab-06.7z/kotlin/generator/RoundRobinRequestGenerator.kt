package generator

class RoundRobinRequestGenerator(generator: IGenerator): RequestGenerator(generator) {
    private var currReceiver = 0

    private fun updatePos() {
        if (++currReceiver == receivers.size) currReceiver = 0
    }

    override fun emitRequest(): Boolean {
        generatedRequests++
        val curr = receivers[currReceiver]
        updatePos()

        if (curr.offer()) {
            return true
        }

        return false
    }
}