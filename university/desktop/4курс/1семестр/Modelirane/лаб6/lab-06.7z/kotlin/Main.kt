import generator.ConstGenerator
import generator.RequestGenerator
import generator.RoundRobinRequestGenerator
import generator.UniformGenerator
import processor.RequestProcessor
import storage.Storage

object Main {

    @JvmStatic
    fun main(args: Array<String>) {
        val model = hardcodedInput()
        printResults(model)
    }

    fun hardcodedInput(): Model {
        val clientM: Double = 5.0
        val clientD: Double = 3.0

        val rc93M: Double = 20.0
        val rc93D: Double = 2.0
        val rc93q: Int = 4

        val rc95M: Double = 5.0
        val rc95D: Double = 3.0
        val rc95q: Int = 3

        val rcDM: Double = 15.0
        val rcDD: Double = 1.0
        val rcDq: Int = 2

        val pd0M: Double = 7.0

        val pd1M: Double = 5.0
        val pd1D: Double = 1.0
        val pdq: Int = 10

        val cCount: Int = 300

        println("Клиенты:")
        println("Интервал = $clientM +- $clientD")
        println("К-во заявок = $cCount")

        println("Колонки:")
        println("\t93 Интервал = $rc93M +- $rc93D")
        println("\t93 Очередь  = $rc93q")
        println("\t95 Интервал = $rc95M +- $rc95D")
        println("\t95 Очередь  = $rc95q")
        println("\tД  Интервал = $rcDM +- $rcDD")
        println("\tД  Очередь  = $rcDq")

        println("Оплата:")
        println("\t#1 Интервал = $pd0M")
        println("\t#2 Интервал = $pd1M +- $pd1D")
        println("\t   Очередь  = $pdq")

        val clientGen = RoundRobinRequestGenerator(UniformGenerator(clientM, clientD))
        val refuelingColumns = listOf(
            RequestProcessor(UniformGenerator(rc93M, rc93D), Storage(rc93q)),
            RequestProcessor(UniformGenerator(rc95M, rc95D), Storage(rc95q)),
            RequestProcessor(UniformGenerator(rcDM, rcDD), Storage(rcDq)),
        )

        val paymantStorage = Storage(pdq)
        val payDesks = listOf(
            RequestProcessor(ConstGenerator(pd0M), paymantStorage),
            RequestProcessor(UniformGenerator(pd1M, pd1D), paymantStorage),
        )

        return Model(
            clientGen = clientGen,
            refuelingColumns = refuelingColumns,
            payDesks = payDesks,
            cCount = cCount
        )

    }

    fun printResults(model: Model) {
        val (denialP, missedCount) = model.eventBasedModelling()
        println(" -------- Результаты моделирования --------------------")
        println("Вероятность отказа:    $denialP")
        println("Необработанные заявки: $missedCount")

    }
}