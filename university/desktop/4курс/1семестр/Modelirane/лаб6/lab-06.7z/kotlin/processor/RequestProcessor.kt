package processor

import generator.IGenerator
import generator.RequestGenerator
import storage.Storage

class RequestProcessor(
    generator: IGenerator,
    val inStorage: Storage
): RequestGenerator(generator) {
    var processedRequests: Int = 0
        private set

    fun process(): Boolean {
        if (inStorage.isEmpty()) {
            return false
        }

        if (emitRequest()) {
            inStorage.pull()
            processedRequests++

            return true
        }

        return false
    }

    override fun toString(): String {
        return "RequestProcessor{procesedRequests = $processedRequests,\n\t${inStorage.toString()}\n\t${super.toString()}}"
    }
}