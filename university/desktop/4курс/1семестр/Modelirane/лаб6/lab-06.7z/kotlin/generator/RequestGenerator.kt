package generator

import storage.Storage

open class RequestGenerator(var generator: IGenerator) {
    protected val receivers: ArrayList<Storage> = arrayListOf()
    var generatedRequests: Int = 0
        protected set
    var nextEventTime: Double = 0.0

    fun addReceiver(receiver: Storage) {
        if (receiver !in receivers){
            receivers.add(receiver)
        }
    }

    fun removeReceiver(receiver: Storage) = receivers.remove(receiver)

    fun generateTime() = generator.next()

    // Finds firs free receiver and emits request
    open fun emitRequest(): Boolean {
        if (receivers.size == 0) return true

        for (receiver in receivers) {
            if (receiver.offer()) {
                return true
            }
        }

        return false
    }

    override fun toString(): String {
        return "RequestGenerator(generatedRequests=$generatedRequests, nextEventTime=$nextEventTime)"
    }


}