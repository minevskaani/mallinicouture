package generator

import org.apache.commons.math3.distribution.UniformRealDistribution

class UniformGenerator(m: Double, d: Double): IGenerator {
    private val distribution = UniformRealDistribution(m - d, m + d)

    override fun next() = distribution.sample()
}