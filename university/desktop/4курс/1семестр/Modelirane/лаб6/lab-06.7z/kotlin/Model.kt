import generator.RequestGenerator
import processor.RequestProcessor
import java.util.ArrayList

class Model(
    private val clientGen: RequestGenerator,
    private val refuelingColumns: List<RequestProcessor>,
    private val payDesks: List<RequestProcessor>,
    private val cCount: Int
) {
    private val devices: ArrayList<RequestGenerator> = arrayListOf()

    init {
        // Link storages
        refuelingColumns.forEach {
            clientGen.addReceiver(it.inStorage)
        }
        payDesks.forEach { payDesk ->
            refuelingColumns.forEach { refuelingColumn ->
                refuelingColumn.addReceiver(payDesk.inStorage)
            }
        }

        devices.add(clientGen)
        devices.addAll(refuelingColumns)
        devices.addAll(payDesks)
    }

    fun eventBasedModelling(): Pair<Double, Int> {
        // Init time
        devices.forEach { it.nextEventTime = 0.0 }

        var droppedRequests: Int = 0
        var stopAt = 1000
        var currentTime = 0.0
        while (payDesks.map { it.processedRequests }.sum() < cCount) {
            currentTime = clientGen.nextEventTime

            // Sync time
            devices.forEach { if (it.nextEventTime < currentTime) currentTime = it.nextEventTime }

            for (device in devices) {
                // Find device with min time
                if (currentTime.deltaEquals(device.nextEventTime)) {
                    when (device) {
                        is RequestProcessor -> {
                            if (device in payDesks) {
                                print("")
                            }
                            device.process()
                            device.nextEventTime = currentTime + device.generateTime()
                        }
                        else -> {
                            if (!clientGen.emitRequest()) {
                                droppedRequests++
                            }

                            clientGen.nextEventTime = currentTime + clientGen.generateTime()
                        }
                    }

                    //print(currentTime, droppedRequests)
                    //stopAt--
                    //if (stopAt <= 0) break;
                }
            }
            //if (stopAt <= 0) break;
        }
        print(currentTime, droppedRequests)

        return Pair(droppedRequests.toDouble() / cCount, droppedRequests)
    }
    private fun print(currentTime: Double, droppedRequests: Int) {
        println("---------------------------------------")
        println("dropped: $droppedRequests")
        println("currTime = $currentTime")
        println("::generator:")
        println(clientGen.toString())
        println("::refuelingColumns:")
        refuelingColumns.forEach { println(it.toString()) }
        println("::payDesks:")
        payDesks.forEach { println(it.toString()) }

    }
}

fun Double.deltaEquals(other: Double): Boolean {
    return Math.abs(this - other) < 1e-5
}