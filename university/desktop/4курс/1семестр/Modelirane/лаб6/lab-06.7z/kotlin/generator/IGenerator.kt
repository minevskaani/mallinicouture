package generator

interface IGenerator {
    fun next(): Double
}